function [as2] = horzcat(as, varargin)


error('Cannot concatenate actstruct horizontaly, try as = [as1 ; as2] instead')

